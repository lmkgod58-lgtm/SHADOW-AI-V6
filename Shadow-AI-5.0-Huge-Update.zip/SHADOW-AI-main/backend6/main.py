import re
from fastapi import FastAPI
from pydantic import BaseModel, Field
app=FastAPI(title="Shadow AI Context Compressor",version="2.0")
class CompactRequest(BaseModel): text:str=Field(min_length=1,max_length=50000); target_chars:int=6000

def compact(text,target):
    text=re.sub(r"\s+"," ",text).strip()
    if len(text)<=target:return text
    # Keep the beginning (goals/context) and end (latest decisions), with a small middle sample.
    head=int(target*0.38);tail=int(target*0.52);middle=max(0,target-head-tail)
    start=text[:head];end=text[-tail:]
    mid=text[max(0,len(text)//2-middle//2):max(0,len(text)//2-middle//2)+middle]
    return f"EARLY CONTEXT: {start}\n\nMIDDLE CONTEXT: {mid}\n\nLATEST CONTEXT: {end}"
@app.get("/")
def root():return {"status":"context compressor operational","provider":"local"}
@app.get("/health")
def health():return {"status":"ok"}
@app.post("/compact")
def compact_endpoint(req:CompactRequest):
    target=max(1500,min(12000,req.target_chars));out=compact(req.text,target);return {"summary":out,"compressed":len(out)<len(req.text)}
