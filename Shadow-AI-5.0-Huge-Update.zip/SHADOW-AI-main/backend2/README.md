# Shadow AI Memory Service
Deploy this service on Render. Set `MONGO_URI` for persistent MongoDB storage. SQLite is only a fallback and may be ephemeral on free hosting.
Health endpoint: `/health`.
