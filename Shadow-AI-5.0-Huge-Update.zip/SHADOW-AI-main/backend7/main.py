import re
from fastapi import FastAPI
from pydantic import BaseModel,Field
app=FastAPI(title="Shadow AI Verification Service",version="2.0")
class VerifyRequest(BaseModel):answer:str=Field(min_length=1,max_length=20000);evidence:str="";request:str=""
@app.get("/")
def root():return {"status":"verification operational","mode":"heuristic"}
@app.get("/health")
def health():return {"status":"ok"}
@app.post("/verify")
def verify(req:VerifyRequest):
    issues=[];a=req.answer.strip();e=req.evidence.strip()
    if not a:issues.append("empty answer")
    if "according to my research" in a.lower() and not e:issues.append("answer claims research without supplied evidence")
    urls=re.findall(r"https?://\S+",a)
    if urls and not e:issues.append("answer contains URLs but no evidence block was supplied")
    confidence="high" if not issues else "review"
    return {"verified":not issues,"confidence":confidence,"issues":issues,"answer":a}
