# Shadow AI 5.0

A lightweight multi-agent AI system designed for free-tier hosting.

## Architecture

### Railway: AI services
- `backend/` — Shadow Core + local Qwen2.5-0.5B. Conversation, routing, memory/research retrieval, final response.
- `backend3/` — Technical Agent. Coding, backend/server/DevOps analysis, research, safe Python syntax testing, and escalation to the deep model.
- `backend4/` — Deep Reasoning Agent. Local Qwen3-1.7B Q2_K, loaded lazily only when difficult reasoning is requested.

### Render: lightweight services
- `backend2/` — persistent memory. MongoDB preferred, SQLite fallback.
- `backend5/` — multi-source web research and safe public-page fetching.
- `backend6/` — deterministic context compression. No AI key and very low RAM usage.
- `backend7/` — lightweight verification checks. No AI key.

## Team workflow

Simple request → Qwen2.5-0.5B.

Coding/technical request → Tech Agent → research/tools → Qwen core → safe test when code is available.

Very hard request → Tech Agent/Qwen core → Qwen3-1.7B → final synthesis.

The agents do not all load models at once. This is essential for 1 GB Railway services.

## Model sizes / RAM reality

The official Qwen2.5-0.5B GGUF Q3_K_M is about 432 MB. Qwen3-1.7B Q2_K is about 880 MB in the referenced GGUF repository. Model file size is not total runtime RAM, so both services use one worker, one CPU thread, mmap, small contexts and bounded output. The Qwen3 service is therefore a best-effort 1 GB deployment and may still require more RAM depending on runtime overhead.

## No provider API keys required for the core AI

The AI brains run locally from GGUF weights. OpenAI/Anthropic keys are not required by this architecture. External web research uses public endpoints and MongoDB is external storage.

## Android APK

`frontend/` is the Kivy client. It explicitly declares `INTERNET` and `ACCESS_NETWORK_STATE`, uses certifi for HTTPS verification, sends UTF-8 request bodies, handles Android keyboard resize, keeps message text inside self-sizing bubbles, retries one transient network failure, and shows the actual network error instead of falsely claiming Railway is offline.

Put `background.jpg` in `frontend/`. `intro.mp4` is optional. The UI will attempt to play it on startup when the installed Kivy video provider supports it.

## Required Railway variables

See `backend/.env.example`, `backend3/.env.example`, and `backend4/.env.example`.

Set service URLs after deployment:
- Main Core → `TECH_AGENT_URL`, `DEEP_REASONING_URL`, `RESEARCH_BACKEND_URL`, `VERIFIER_URL`, `MEMORY_BACKEND_URL`
- Tech Agent → `CORE_URL`, `DEEP_REASONING_URL`, `RESEARCH_BACKEND_URL`

Never put service secrets or database credentials in the APK.
