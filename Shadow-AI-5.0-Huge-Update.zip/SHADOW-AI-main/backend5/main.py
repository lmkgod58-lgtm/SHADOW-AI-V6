import html, re, socket, ipaddress, subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import quote_plus, urlparse, urljoin
import requests
from bs4 import BeautifulSoup
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app=FastAPI(title="Shadow AI Research & Web Intelligence",version="5.0")
S=requests.Session();S.headers.update({"User-Agent":"ShadowAI-Research/5.0","Accept-Language":"en-US,en;q=0.8"})
class ResearchRequest(BaseModel): query:str=Field(min_length=1,max_length=2000); max_sources:int=8
class FetchRequest(BaseModel): url:str=Field(min_length=8,max_length=2000)

def safe_target(url):
    p=urlparse(url)
    if p.scheme not in {"http","https"} or not p.hostname: raise HTTPException(400,"Only public HTTP/HTTPS URLs are allowed")
    try:
        for info in socket.getaddrinfo(p.hostname,None):
            ip=ipaddress.ip_address(info[4][0])
            if any([ip.is_private,ip.is_loopback,ip.is_link_local,ip.is_reserved,ip.is_multicast,ip.is_unspecified]): raise HTTPException(400,"Private or local network targets are blocked")
    except socket.gaierror: raise HTTPException(400,"Host could not be resolved")
    return p

def duck(q):
    r=S.get(f"https://html.duckduckgo.com/html/?q={quote_plus(q)}",timeout=10);r.raise_for_status();soup=BeautifulSoup(r.text,"html.parser");out=[]
    for x in soup.select(".result")[:6]:
        a=x.select_one(".result__a");s=x.select_one(".result__snippet")
        if a:out.append({"source":"DuckDuckGo","title":html.unescape(a.get_text(" ",strip=True)),"url":a.get("href","") ,"text":html.unescape(s.get_text(" ",strip=True) if s else "")})
    return out

def wiki(q):
    r=S.get("https://en.wikipedia.org/w/api.php",params={"action":"query","list":"search","srsearch":q,"format":"json","srlimit":4},timeout=8);r.raise_for_status();out=[]
    for x in r.json().get("query",{}).get("search",[]):out.append({"source":"Wikipedia","title":x.get("title","Wikipedia"),"url":"https://en.wikipedia.org/wiki/"+x.get("title","").replace(" ","_"),"text":BeautifulSoup(x.get("snippet",""),"html.parser").get_text(" ",strip=True)})
    return out

def github(q):
    r=S.get("https://api.github.com/search/repositories",params={"q":q,"per_page":4},timeout=8)
    if r.status_code>=400:return []
    return [{"source":"GitHub","title":x.get("full_name","GitHub"),"url":x.get("html_url",""),"text":x.get("description") or "No description."} for x in r.json().get("items",[])]

def arxiv(q):
    r=S.get("https://export.arxiv.org/api/query",params={"search_query":f"all:{q}","start":0,"max_results":4},timeout=10);r.raise_for_status();soup=BeautifulSoup(r.text,"xml");out=[]
    for e in soup.find_all("entry"):out.append({"source":"arXiv","title":e.title.get_text(" ",strip=True) if e.title else "arXiv","url":e.id.get_text(strip=True) if e.id else "","text":e.summary.get_text(" ",strip=True)[:1800] if e.summary else ""})
    return out

def research(q,max_sources=8):
    jobs={"DuckDuckGo":lambda:duck(q),"Wikipedia":lambda:wiki(q),"GitHub":lambda:github(q),"arXiv":lambda:arxiv(q)}
    low=q.lower()
    if any(x in low for x in ["python","programming","api","javascript","code"]):jobs["PythonDocs"]=lambda:duck("site:docs.python.org "+q)
    if any(x in low for x in ["security","vulnerability","xss","owasp","cve"]):jobs["OWASP"]=lambda:fetch("https://owasp.org/www-project-top-ten/")
    results=[]
    with ThreadPoolExecutor(max_workers=min(4,len(jobs))) as pool:
        fs={pool.submit(fn):name for name,fn in jobs.items()}
        for f in as_completed(fs):
            try:results.extend([x for x in (f.result() or []) if x.get("text")])
            except Exception as e:print("[Research]",fs[f],type(e).__name__,e)
    unique=[];seen=set()
    for x in results:
        key=(x.get("url") or x.get("title")).lower()
        if key in seen:continue
        seen.add(key);unique.append(x)
        if len(unique)>=max_sources:break
    evidence="\n\n".join(f"[{i}] {x.get('title','Source')}\nURL: {x.get('url','')}\n{x.get('text','')[:1800]}" for i,x in enumerate(unique,1))
    return evidence,unique

def fetch(url):
    safe_target(url);r=S.get(url,timeout=(5,12),allow_redirects=False)
    for _ in range(3):
        if not 300<=r.status_code<400:break
        loc=r.headers.get("location")
        if not loc:break
        target=urljoin(r.url,loc);safe_target(target);r=S.get(target,timeout=(5,12),allow_redirects=False)
    r.raise_for_status();soup=BeautifulSoup(r.text,"html.parser")
    for t in soup(["script","style","noscript"]):t.decompose()
    text=re.sub(r"\s+"," ",soup.get_text(" ",strip=True))
    return [{"source":urlparse(r.url).netloc,"title":soup.title.get_text(" ",strip=True) if soup.title else urlparse(r.url).netloc,"url":r.url,"text":text[:12000]}]

@app.get("/")
def root():return {"status":"research/web intelligence operational","sources":["DuckDuckGo","Wikipedia","GitHub","arXiv","Python docs","OWASP"]}
@app.get("/health")
def health():return {"status":"ok"}
@app.post("/research")
def research_endpoint(req:ResearchRequest):
    evidence,sources=research(req.query,max(1,min(10,req.max_sources)));return {"query":req.query,"evidence":evidence,"sources":sources}
@app.post("/fetch")
def fetch_endpoint(req:FetchRequest):
    try:return {"results":fetch(req.url)}
    except HTTPException:raise
    except Exception as e:raise HTTPException(502,f"Fetch failed: {type(e).__name__}")
