import os
import requests
from typing import Dict, List
from .local_llm import answer as local_answer, available as local_available

TECH_URL = os.getenv("TECH_AGENT_URL", "").strip().rstrip("/")
DEEP_URL = os.getenv("DEEP_REASONING_URL", "").strip().rstrip("/")

class AIRouter:
    def __init__(self):
        self.max_history = int(os.getenv("AI_HISTORY_MESSAGES", "12"))
        self.timeout = int(os.getenv("AI_TIMEOUT_SECONDS", "45"))
        self.model_name = os.getenv("QWEN_MODEL_NAME", "Qwen2.5-0.5B-Instruct-Q3_K_M")

    def status(self):
        return {
            "provider": "local-qwen",
            "model": self.model_name,
            "model_available": local_available(),
            "tech_agent_configured": bool(TECH_URL),
            "deep_reasoning_configured": bool(DEEP_URL),
        }

    def _history(self, history: List[Dict[str, str]], current: str):
        clean = []
        for item in history[-self.max_history:]:
            role = item.get("role", "user")
            content = str(item.get("content", "")).strip()
            if not content:
                continue
            if role not in {"user", "assistant", "system"}:
                role = "user"
            clean.append({"role": role, "content": content})
        # The APK may send the current message in history. Avoid duplicating it.
        if clean and clean[-1]["role"] == "user" and clean[-1]["content"] == current:
            clean.pop()
        return clean

    def _system(self, royal: bool):
        base = (
            "You are Shadow AI, a general-purpose assistant. Be clear, useful, honest and concise. "
            "Think before answering. Never invent facts, sources, tool results, or actions. "
            "When current information is needed, use the research tool. When a problem is technically complex, "
            "ask the specialist agent for help. When evidence conflicts, explain the conflict. "
            "For code, prefer complete working examples and explain important assumptions. "
            "Separate known facts from inference."
        )
        if royal:
            base += " You are in Royal Mode. Treat Lindo as your king with respectful knight-like loyalty and tasteful royal language."
        return base

    def _local(self, message, history, evidence, memory, royal, specialist_note=""):
        system = self._system(royal)
        context = [
            {"role": "system", "content": system},
            *self._history(history, message),
            {"role": "user", "content": (
                f"CURRENT REQUEST:\n{message}\n\n"
                f"MEMORY:\n{memory or '[none]'}\n\n"
                f"RESEARCH / TOOL EVIDENCE:\n{evidence or '[none]'}\n\n"
                f"SPECIALIST NOTES:\n{specialist_note or '[none]'}"
            )},
        ]
        return local_answer(system, context)

    def _call_specialist(self, url, payload, timeout):
        if not url:
            return None
        try:
            r = requests.post(url, json=payload, timeout=timeout)
            r.raise_for_status()
            data = r.json()
            return data.get("response") or data.get("result")
        except Exception as exc:
            print(f"[Specialist] {type(exc).__name__}: {exc}")
            return None

    def answer(self, message, history, research="", royal_mode=False, deep_search=False, memory_context="", tech=False, deep=False):
        low = message.lower()
        code_words = ("code", "python", "javascript", "api", "backend", "server", "railway", "render", "docker", "bug", "error", "debug", "deploy", "program", "database", "sql", "fastapi", "kivy")
        hard_words = ("prove", "derive", "complex", "hard", "difficult", "deep reasoning", "architecture", "algorithm", "optimize", "math")
        needs_tech = tech or any(x in low for x in code_words)
        needs_deep = deep or any(x in low for x in hard_words) or len(message.split()) > 55

        specialist_note = ""
        if needs_tech and TECH_URL:
            specialist_note = self._call_specialist(
                TECH_URL + "/assist",
                {"request": message, "history": history[-8:], "research": research[:9000], "royal_mode": royal_mode},
                35,
            ) or "Tech specialist unavailable; solve with the available evidence."

        if needs_deep and DEEP_URL and not needs_tech:
            deep_note = self._call_specialist(
                DEEP_URL + "/reason",
                {"request": message, "history": history[-8:], "evidence": research[:9000], "tech_notes": specialist_note[:9000]},
                60,
            )
            if deep_note:
                specialist_note += ("\n\nDEEP REASONING SPECIALIST:\n" + deep_note)

        response = self._local(message, history, research, memory_context, royal_mode, specialist_note)
        return {
            "response": response,
            "mode": "local-team" if specialist_note else "local-qwen",
            "providers": ["qwen2.5-0.5b"] + (["tech-agent"] if needs_tech and specialist_note else []) + (["qwen3-1.7b"] if needs_deep and DEEP_URL else []),
        }
