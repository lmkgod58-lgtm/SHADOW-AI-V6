import os
import threading
from pathlib import Path
from typing import List, Dict, Optional

MODEL_PATH = os.getenv("QWEN_MODEL_PATH", "/data/models/qwen2.5-0.5b-q3_k_m.gguf")
MODEL_URL = os.getenv(
    "QWEN_MODEL_URL",
    "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q3_k_m.gguf",
)
N_CTX = int(os.getenv("QWEN_CONTEXT", "1024"))
N_THREADS = int(os.getenv("QWEN_THREADS", "1"))
N_BATCH = int(os.getenv("QWEN_BATCH", "64"))
MAX_TOKENS = int(os.getenv("QWEN_MAX_TOKENS", "700"))

_llama = None
_lock = threading.Lock()


def _ensure_model_file() -> str:
    path = Path(MODEL_PATH)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.stat().st_size > 10_000_000:
        return str(path)

    import urllib.request
    tmp = path.with_suffix(path.suffix + ".part")
    print(f"[Qwen] downloading model to {path}")
    urllib.request.urlretrieve(MODEL_URL, tmp)
    tmp.replace(path)
    return str(path)


def _get_llama():
    global _llama
    if _llama is not None:
        return _llama
    with _lock:
        if _llama is not None:
            return _llama
        from llama_cpp import Llama
        model = _ensure_model_file()
        _llama = Llama(
            model_path=model,
            n_ctx=N_CTX,
            n_threads=N_THREADS,
            n_batch=N_BATCH,
            n_gpu_layers=0,
            use_mmap=True,
            use_mlock=False,
            verbose=False,
        )
        print(f"[Qwen] loaded {model}; ctx={N_CTX}, threads={N_THREADS}")
        return _llama


def available() -> bool:
    try:
        import llama_cpp  # noqa: F401
        return True
    except Exception:
        return False


def answer(system: str, messages: List[Dict[str, str]], max_tokens: Optional[int] = None) -> str:
    llm = _get_llama()
    # Qwen2.5 uses the ChatML template supported by llama.cpp.
    with _lock:
        result = llm.create_chat_completion(
            messages=messages,
            max_tokens=max_tokens or MAX_TOKENS,
            temperature=float(os.getenv("QWEN_TEMPERATURE", "0.35")),
            top_p=float(os.getenv("QWEN_TOP_P", "0.9")),
            repeat_penalty=1.08,
        )
    choices = result.get("choices") or []
    if not choices:
        return ""
    msg = choices[0].get("message") or {}
    return str(msg.get("content") or "").strip()
