import os, time, uuid, requests
from threading import BoundedSemaphore
from typing import Dict, List, Optional
from fastapi import FastAPI, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from core.ai_router import AIRouter
from core.code_validator import CodeValidator
from core.research_engine import ResearchEngine
from core.memory_client import MemoryClient

app = FastAPI(title="Shadow AI Main Brain", version="5.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=False, allow_methods=["*"], allow_headers=["*"])
ai = AIRouter(); local_research = ResearchEngine(); validator = CodeValidator(); memory = MemoryClient()
RESEARCH_BACKEND_URL = os.getenv("RESEARCH_BACKEND_URL", "").strip().rstrip("/")
VERIFIER_URL = os.getenv("VERIFIER_URL", "").strip().rstrip("/")
MAX_HISTORY = int(os.getenv("MAX_HISTORY_MESSAGES", "12"))
CHAT_SLOTS = BoundedSemaphore(max(1, int(os.getenv("CHAT_CONCURRENCY", "1"))))
REQUEST_CACHE = {}
REQUEST_CACHE_MAX = 32

class HistoryItem(BaseModel):
    role: str = Field(pattern="^(user|assistant|system)$")
    content: str = Field(max_length=12000)
class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=12000)
    history: List[HistoryItem] = Field(default_factory=list)
    deep_search: bool = False
    royal_mode: bool = False
    memory_context: str = Field(default="", max_length=12000)
    user_id: str = Field(default="default", max_length=200)
    client_request_id: str = Field(default="", max_length=200)

def remote_research(q):
    if not RESEARCH_BACKEND_URL: return None, []
    try:
        r = requests.post(RESEARCH_BACKEND_URL + "/research", json={"query": q, "max_sources": 8}, timeout=18)
        r.raise_for_status(); d = r.json(); return d.get("evidence", ""), d.get("sources", [])
    except Exception as e:
        print("[Research remote]", type(e).__name__, e); return None, []

def save_memory_safe(user_id, role, content):
    try: memory.save_message(user_id, role, content)
    except Exception as e: print("[Memory save]", type(e).__name__, e)

@app.get("/")
def root(): return {"status":"Shadow AI Main Brain operational", "version":"5.0", "ai":ai.status(), "research_backend":bool(RESEARCH_BACKEND_URL), "verifier":bool(VERIFIER_URL), "memory":memory.enabled()}
@app.get("/health")
def health(): return {"status":"ok", "ai":ai.status(), "research_backend":bool(RESEARCH_BACKEND_URL), "verifier":bool(VERIFIER_URL), "memory":memory.enabled()}
@app.get("/tools")
def tools(): return {"local_terminal_tools":local_research.terminal_status(), "research_backend":bool(RESEARCH_BACKEND_URL), "memory":memory.enabled(), "deep_reasoning":ai.status()["deep_reasoning_configured"], "tech_agent":ai.status()["tech_agent_configured"]}
@app.post("/internal/tech-generate")
def internal_tech_generate(req: Dict):
    # Internal service-to-service endpoint. Keep it off the APK and protect it with a shared key in production.
    expected=os.getenv("INTERNAL_SERVICE_KEY","").strip()
    supplied=str(req.get("service_key","")).strip()
    if expected and supplied!=expected: raise HTTPException(401,"Invalid service key")
    prompt=str(req.get("prompt","")).strip()
    if not prompt: raise HTTPException(400,"prompt is required")
    from core.local_llm import answer as local_answer
    system=("You are the coding/technical reasoning worker inside Shadow AI. Produce practical, testable engineering work. "
            "Do not invent API behavior. Prefer minimal reliable changes and include a test plan. Return useful technical content, not meta commentary.")
    try:
        response=local_answer(system,[{"role":"system","content":system},{"role":"user","content":prompt}],max_tokens=750)
        return {"response":response,"model":"qwen2.5-0.5b"}
    except Exception as e:
        print("[internal tech generate]",type(e).__name__,e); raise HTTPException(503,"Local Qwen worker unavailable")

@app.post("/research")
def research_endpoint(req: Dict):
    q = str(req.get("query", "")).strip()
    if not q: raise HTTPException(400, "query is required")
    evidence, sources = local_research.research(q, max_sources=8)
    return {"query":q, "evidence":evidence, "sources":sources}

@app.post("/chat")
def chat(req: ChatRequest, x_client_request_id: Optional[str]=Header(default=None)):
    if not CHAT_SLOTS.acquire(timeout=5): raise HTTPException(429, "Shadow AI is busy processing another request. Please retry shortly.")
    rid = x_client_request_id or req.client_request_id or uuid.uuid4().hex[:12]; started=time.time()
    if rid in REQUEST_CACHE: return REQUEST_CACHE[rid]
    try:
        message=req.message.strip()
        history=[x.model_dump() for x in req.history[-MAX_HISTORY:]]
        if history and history[-1].get("role")=="user" and history[-1].get("content","").strip()==message:
            history=history[:-1]
        memories=memory.search(req.user_id, message) if memory.enabled() else []
        memory_text="\n".join(f"- {m.get('content','')}" for m in memories[:6])
        evidence=req.memory_context.strip(); sources=[]; low=message.lower()
        needs=req.deep_search or any(t in low for t in ["search","research","latest","current","compare","sources","look up","find out","today","2026"])
        if needs:
            evidence2,sources2=remote_research(message)
            if evidence2 is None: evidence2,sources2=local_research.research(message,max_sources=6)
            evidence=(evidence+"\n\n"+evidence2).strip() if evidence and evidence2 else (evidence2 or evidence)
            sources.extend(sources2)
        tech=any(t in low for t in ["code","python","javascript","api","backend","server","railway","render","docker","bug","error","debug","deploy","program","database","sql","fastapi","kivy"])
        hard=any(t in low for t in ["deep reasoning","prove","derive","complex","difficult","hard problem","algorithm","optimize"])
        result=ai.answer(message,history,evidence,req.royal_mode,needs,memory_text,tech=tech,deep=hard)
        response=result.get("response") or "I could not produce an answer. The local Qwen model may not be loaded; check Railway logs."
        if VERIFIER_URL:
            try:
                vr=requests.post(VERIFIER_URL+"/verify",json={"request":message,"answer":response,"evidence":evidence[:10000]},timeout=6); vr.raise_for_status(); vd=vr.json()
                if vd.get("issues"): response += "\n\n[Verification note] " + "; ".join(vd.get("issues",[])[:3])
            except Exception as e: print("[Verifier]",type(e).__name__,e)
        try: response=validator.validate_code_blocks(response)
        except Exception as e: print("[Validator]",e)
        if memory.enabled():
            save_memory_safe(req.user_id,"user",message); save_memory_safe(req.user_id,"assistant",response)
            if any(x in low for x in ["remember that","remember this","don't forget","do not forget","my goal is","my favorite is"]):
                try: memory.save(req.user_id,message,importance=5)
                except Exception as e: print("[Memory durable]",e)
        payload={"response":response,"mode":result.get("mode","unknown"),"providers":result.get("providers",[]),"sources_count":len(sources),"sources":[{"title":x.get("title","Source"),"url":x.get("url","")} for x in sources[:8]],"researched":bool(needs),"memory_used":bool(memories),"request_id":rid,"elapsed_ms":round((time.time()-started)*1000)}
        REQUEST_CACHE[rid]=payload
        if len(REQUEST_CACHE)>REQUEST_CACHE_MAX: REQUEST_CACHE.pop(next(iter(REQUEST_CACHE)))
        return payload
    except HTTPException: raise
    except Exception as e:
        print(f"[CHAT {rid}] {type(e).__name__}: {e}"); raise HTTPException(500, f"Internal Shadow AI error. Request ID: {rid}")
    finally: CHAT_SLOTS.release()
