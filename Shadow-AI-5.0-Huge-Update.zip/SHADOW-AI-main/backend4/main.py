import os, pathlib, threading, urllib.request
from typing import List, Dict
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="Shadow AI Deep Reasoning", version="5.0")
MODEL_PATH = os.getenv("QWEN3_MODEL_PATH", "/data/models/qwen3-1.7b-q2_k.gguf")
MODEL_URL = os.getenv("QWEN3_MODEL_URL", "https://huggingface.co/second-state/Qwen3-1.7B-GGUF/resolve/main/Qwen3-1.7B-Q2_K.gguf")
N_CTX = int(os.getenv("QWEN3_CONTEXT", "768")); N_THREADS = int(os.getenv("QWEN3_THREADS", "1")); N_BATCH = int(os.getenv("QWEN3_BATCH", "32")); MAX_TOKENS = int(os.getenv("QWEN3_MAX_TOKENS", "650"))
_llm=None; _lock=threading.Lock()
class ReasonRequest(BaseModel):
    request:str=Field(min_length=1,max_length=12000); history:List[Dict[str,str]]=Field(default_factory=list); evidence:str=""; tech_notes:str=""

def ensure_file():
    p=pathlib.Path(MODEL_PATH);p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists() and p.stat().st_size>500_000_000:return str(p)
    tmp=p.with_suffix(p.suffix+".part");print(f"[Qwen3] downloading {MODEL_URL}");urllib.request.urlretrieve(MODEL_URL,tmp);tmp.replace(p);return str(p)

def model():
    global _llm
    if _llm is not None:return _llm
    with _lock:
        if _llm is not None:return _llm
        try: from llama_cpp import Llama
        except Exception as e: raise HTTPException(503,f"llama-cpp-python unavailable: {e}")
        _llm=Llama(model_path=ensure_file(),n_ctx=N_CTX,n_threads=N_THREADS,n_batch=N_BATCH,n_gpu_layers=0,use_mmap=True,use_mlock=False,verbose=False)
        print("[Qwen3] loaded deep reasoning model")
        return _llm

def run(req):
    prompt=(f"USER REQUEST:\n{req.request}\n\nRECENT HISTORY:\n{req.history[-8:]}\n\nEVIDENCE:\n{req.evidence[:8000] or '[none]'}\n\nTECH NOTES:\n{req.tech_notes[:8000] or '[none]'}")
    system="You are Shadow AI's deep reasoning specialist. Solve difficult problems carefully. Check assumptions, reason step by step internally, test conclusions against evidence, identify contradictions, and give a precise practical result. Do not invent facts or claim tests you did not run. Focus on mathematics, algorithms, architecture, difficult debugging and complex planning."
    with _lock:
        out=model().create_chat_completion(messages=[{"role":"system","content":system},{"role":"user","content":prompt}],max_tokens=MAX_TOKENS,temperature=0.25,top_p=0.9,repeat_penalty=1.08)
    return str(out.get("choices",[{}])[0].get("message",{}).get("content","")).strip()

@app.get("/")
def root():return {"status":"deep reasoning operational","model":"Qwen3-1.7B-Q2_K","lazy_loaded":_llm is not None}
@app.get("/health")
def health():return {"status":"ok","model":"Qwen3-1.7B-Q2_K","loaded":_llm is not None}
@app.post("/reason")
def reason(req:ReasonRequest):
    try:return {"response":run(req),"model":"qwen3-1.7b"}
    except HTTPException:raise
    except Exception as e:print("[Qwen3]",type(e).__name__,e);raise HTTPException(500,"Deep reasoning model failed; check service logs")
