# Shadow AI 5.0 deployment map

## Railway

1. `backend/` — Shadow Core, local Qwen2.5-0.5B Q3_K_M. Set `TECH_AGENT_URL`, `DEEP_REASONING_URL`, `RESEARCH_BACKEND_URL`, `VERIFIER_URL`, `MEMORY_BACKEND_URL` and `INTERNAL_SERVICE_KEY`.
2. `backend3/` — Tech Agent. Set `CORE_URL`, `CORE_SERVICE_KEY`, `DEEP_REASONING_URL`, `RESEARCH_BACKEND_URL`.
3. `backend4/` — Qwen3-1.7B Q2_K deep-reasoning specialist. This model is intentionally lazy-loaded.

## Render

1. `backend2/` — MongoDB memory. Use MongoDB for durable storage. SQLite is only a fallback.
2. `backend5/` — multi-source web research and public-page retrieval.
3. `backend6/` — deterministic context compression, no AI key.
4. `backend7/` — lightweight verification, no AI key.

## Important RAM note

The Qwen2.5-0.5B Q3_K_M model file is about 432 MB. The Qwen3-1.7B Q2_K model file is about 880 MB in the selected GGUF repository. File size is not total RAM, so the deep service is deliberately one worker, one CPU thread, mmap enabled, and a small context. The 1 GB Railway plan is still a tight best-effort target for Qwen3 1.7B and may require a larger service if it OOMs.

## APK

`frontend/buildozer.spec` explicitly declares INTERNET and ACCESS_NETWORK_STATE. HTTPS requests use certifi, UTF-8 request bytes, one retry, request IDs for backend idempotency, keyboard resize mode, and self-sizing bubbles whose text is constrained inside the bubble.
