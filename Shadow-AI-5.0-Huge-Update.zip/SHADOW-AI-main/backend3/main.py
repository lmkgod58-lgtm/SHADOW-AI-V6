import os, re, subprocess, tempfile, pathlib, requests
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="Shadow AI Tech Agent", version="5.0")
CORE_URL = os.getenv("CORE_URL", "").strip().rstrip("/")
CORE_SERVICE_KEY = os.getenv("CORE_SERVICE_KEY", "").strip()
DEEP_URL = os.getenv("DEEP_REASONING_URL", "").strip().rstrip("/")
RESEARCH_URL = os.getenv("RESEARCH_BACKEND_URL", "").strip().rstrip("/")
TIMEOUT = int(os.getenv("AGENT_TIMEOUT", "35"))

class AssistRequest(BaseModel):
    request: str = Field(min_length=1, max_length=12000)
    history: list = Field(default_factory=list)
    research: str = Field(default="", max_length=12000)
    royal_mode: bool = False

class TestRequest(BaseModel):
    code: str = Field(min_length=1, max_length=30000)
    language: str = "python"

SYSTEM = """You are Shadow AI's senior software engineer and technical agent. You specialize in Python, APIs, FastAPI, Kivy, Android builds, Docker, Linux, Railway, Render, databases, networking and debugging. Inspect the problem, form a concrete plan, use research when documentation or current platform behavior matters, write robust code, and never claim that code works until it has been checked. Prefer small, testable changes. Identify assumptions and failure modes."""

def call_json(url, path, payload, timeout=TIMEOUT):
    if not url: return None
    try:
        r = requests.post(url + path, json=payload, timeout=timeout)
        r.raise_for_status(); return r.json()
    except Exception as exc:
        print(f"[Tech call] {type(exc).__name__}: {exc}"); return None

def research(query):
    data = call_json(RESEARCH_URL, "/research", {"query": query, "max_sources": 6}, 18)
    return data.get("evidence", "") if data else ""

def qwen_generate(prompt):
    data = call_json(CORE_URL, "/internal/tech-generate", {"prompt": prompt, "service_key": CORE_SERVICE_KEY}, 35)
    return data.get("response", "") if data else ""

def deep_reason(prompt):
    data = call_json(DEEP_URL, "/reason", {"request": prompt, "history": [], "evidence": "", "tech_notes": ""}, 60)
    return data.get("response", "") if data else ""

def test_python(code):
    with tempfile.TemporaryDirectory(prefix="shadow-test-") as td:
        path = pathlib.Path(td) / "candidate.py"
        path.write_text(code, encoding="utf-8")
        try:
            p = subprocess.run(["python", "-m", "py_compile", str(path)], capture_output=True, text=True, timeout=5)
            return {"passed": p.returncode == 0, "stdout": p.stdout[-2000:], "stderr": p.stderr[-4000:]}
        except subprocess.TimeoutExpired:
            return {"passed": False, "stdout": "", "stderr": "Python syntax test timed out."}

def looks_like_code(text):
    return "```" in text or any(x in text for x in ["def ", "import ", "from fastapi", "class ", "const ", "function "])

def extract_python(text):
    blocks = re.findall(r"```(?:python|py)?\s*\n(.*?)```", text, flags=re.S|re.I)
    return max(blocks, key=len) if blocks else ""

@app.get("/")
def root(): return {"status":"tech agent operational","specialties":["coding","backend","servers","DevOps","debugging","testing"]}
@app.get("/health")
def health(): return {"status":"ok","core":bool(CORE_URL),"deep_reasoning":bool(DEEP_URL),"research":bool(RESEARCH_URL)}

@app.post("/assist")
def assist(req: AssistRequest):
    context = req.research
    if not context:
        context = research(req.request)
    prompt = f"{SYSTEM}\n\nREQUEST:\n{req.request}\n\nRESEARCH:\n{context or '[none]'}\n\nReturn a technical analysis, proposed fix, implementation, and a TEST PLAN. Do not pretend tests were run."
    draft = qwen_generate(prompt)
    if not draft:
        raise HTTPException(503, "Core Qwen specialist is unavailable")

    test_result = None
    py = extract_python(draft)
    if py:
        test_result = test_python(py)

    hard = len(req.request.split()) > 70 or any(x in req.request.lower() for x in ["architecture", "race condition", "memory leak", "kernel", "complex", "production outage"])
    deep = deep_reason(req.request + "\n\nTECH AGENT DRAFT:\n" + draft[:9000]) if hard and DEEP_URL else ""

    if deep:
        final_prompt = f"{SYSTEM}\n\nUSER REQUEST:\n{req.request}\n\nTECH DRAFT:\n{draft[:9000]}\n\nTEST RESULT:\n{test_result}\n\nDEEP REASONING REVIEW:\n{deep[:9000]}\n\nProduce the corrected engineering recommendation. Explicitly distinguish tested facts from proposed changes."
        final = qwen_generate(final_prompt) or draft
    else:
        final = draft

    return {"response": final, "tested": bool(test_result), "test_result": test_result, "used_research": bool(context), "used_deep_reasoning": bool(deep)}

@app.post("/test")
def test(req: TestRequest):
    if req.language.lower() not in {"python", "py"}:
        raise HTTPException(400, "Safe automated execution currently supports Python syntax checks only")
    return test_python(req.code)
