# Shadow AI Tech Agent

Railway specialist for coding, backend/server/DevOps troubleshooting and safe testing.

It can call:
- Shadow Core `/internal/tech-generate` for Qwen2.5-0.5B generation
- Render research `/research` for current documentation and web evidence
- Deep Reasoning `/reason` for difficult technical problems

Automated code testing is intentionally safe and bounded. The public `/test` endpoint performs Python syntax checks only; it does not execute arbitrary user programs.
