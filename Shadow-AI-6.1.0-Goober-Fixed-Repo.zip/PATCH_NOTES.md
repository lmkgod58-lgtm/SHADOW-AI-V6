# Shadow AI 6.1.0 patch notes

## Debug fixes
- Hardened the orchestrator against malformed history and unavailable specialist services.
- Fixed frontend health parsing to match the backend health schema.
- Fixed frontend research source counting.
- Replaced broken Render blueprint paths pointing at deleted `backend*` directories.
- Verified all Python services compile and import successfully.

## Engineering upgrades
- Local GGUF runtime now supports configurable context, batch, CPU threads, GPU layers, mmap and mlock.
- Model downloads are written to a temporary `.part` file and validated before replacement.
- Workspace writes are atomic and text files are UTF-8 validated.
- Workspace test execution uses argument arrays with no shell invocation.
- Workspace test flags and paths are restricted.
- Workspace snapshots are timestamped while keeping a latest snapshot.
- Added workspace `/project/validate`.
- Research redirect destinations are revalidated against SSRF/private-network rules.
- Added request size limits and safe Pydantic defaults.
- Added specialist isolation and retry handling.
- Added eight architecture/security regression tests.

## Verification performed
- `python -m compileall -q services tests frontend` -> PASS
- `python -m pytest -q` -> 8 passed
- Import check for all backend services -> PASS
- Docker image build was not run because Docker is not installed in the local test environment.
