# 6.0.0
- Rebuilt the AI layer around three independent Qwen roles.
- Added persistent repo/workspace state, patches, tests and snapshots.
- Added adversarial reasoning and evidence consensus.
- Added multi-source research and durable memory services.
- Preserved the existing Kivy frontend foundation and Royal Mode.
