from pathlib import Path

ROOT = Path(__file__).parents[1]


def read(path):
    return (ROOT / path).read_text(encoding="utf-8")


def test_models():
    assert "Qwen3-8B" in read("services/main/main.py")
    assert "Qwen2.5-Coder-14B" in read("services/coder/main.py")
    assert "Qwen3-14B" in read("services/reasoner/main.py")


def test_repo_state():
    s = read("services/workspace/main.py")
    for endpoint in (
        "/project/tree",
        "/project/file",
        "/project/patch",
        "/project/test",
        "/project/snapshot",
        "/project/validate",
    ):
        assert endpoint in s


def test_no_openai_dependency():
    for path in (ROOT / "services").rglob("*.py"):
        assert "openai" not in path.read_text(encoding="utf-8").lower()


def test_render_paths_exist():
    render = read("render.yaml")
    for service in ("main", "coder", "reasoner", "research", "memory", "workspace", "context", "verifier"):
        assert f"./services/" in render
    assert "backend2" not in render
    assert "backend5" not in render


def test_consensus():
    assert "/consensus" in read("services/verify/main.py")


def test_workspace_command_is_not_shell():
    s = read("services/workspace/main.py")
    assert "shell=True" not in s
    assert "shlex.split" in s
    assert "subprocess.run(" in s


def test_research_redirects_are_revalidated():
    s = read("services/research/main.py")
    assert "_public_host" in s
    assert "for _ in range(3)" in s
    assert "allow_redirects=False" in s


def test_frontend_version_and_health():
    s = read("frontend/buildozer.spec")
    f = read("frontend/main.py")
    assert "version = 6.1.0" in s
    assert 'result.get("model"' in f
