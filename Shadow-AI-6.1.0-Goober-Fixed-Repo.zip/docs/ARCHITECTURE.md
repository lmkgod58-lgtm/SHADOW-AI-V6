# Shadow AI 6.0

The model is not the whole product. Three specialized Qwen agents are surrounded by memory, research, persistent repository state, local execution, verification and self-correction.

The repository/workspace is authoritative for project state. Conversation memory is separate. The system must never claim that code was tested unless a real tool returned a test result.

Consensus is evidence-based, not majority voting. If agents disagree, research and testing are repeated. If they agree but tests fail, the tests win.
