# Shadow AI 6.1.0

Self-hosted, local-first, repo-first multi-agent AI. No OpenAI API is required or used.

## What changed in 6.1.0

- Fixed the stale/broken Render blueprint that referenced nonexistent `backend2`-style directories.
- Hardened the local GGUF runtime with configurable context, batch size, threads and GPU layers.
- Added model runtime status to health endpoints.
- Made request/history schemas safer with bounded sizes and factory defaults.
- Improved orchestrator retries, timeouts and specialist isolation so one dead service does not kill the whole chat.
- Research fetching now validates redirect targets and blocks private/loopback/link-local/reserved destinations on every hop.
- Research limits are validated server-side.
- Workspace writes are atomic, UTF-8 validated and path-safe.
- Workspace tests never invoke a shell and only allow a deliberately small test command surface.
- Workspace snapshots are timestamped and the latest snapshot is maintained.
- Added a `/project/validate` integrity check.
- Fixed frontend health parsing and source-count reporting.
- Bumped the Android app version to 6.1.0.
- Preserved the local Qwen architecture and Royal Mode. No OpenAI integration was added.

## AI council

1. **Qwen3-8B**: main orchestration, conversation and synthesis.
2. **Qwen2.5-Coder-14B**: coding, debugging, repository engineering and tests.
3. **Qwen3-14B**: independent reasoning and adversarial review.
4. **Research service**: DuckDuckGo HTML, Wikipedia, GitHub and arXiv retrieval.
5. **Verifier**: evidence/claim sanity checks.
6. **Memory**: SQLite durable memory.
7. **Workspace**: persistent repository source of truth.
8. **Context**: deterministic context compression fallback.

The model files are intentionally not bundled. Set `MODEL_PATH` to a GGUF file, or `MODEL_URL` if the deployment is meant to download one.

## Repo-first workflow

For project work, the intended lifecycle is:

`PLAN -> INSPECT -> RESEARCH -> IMPLEMENT -> TEST -> CRITIQUE -> CORRECT -> TEST AGAIN -> VERIFY -> SNAPSHOT -> EXPORT`

The workspace is persistent and exposes:

- `GET /project/tree`
- `GET /project/file`
- `POST /project/file`
- `POST /project/patch`
- `POST /project/test`
- `POST /project/validate`
- `POST /project/snapshot`

The important part is that the repository itself is updated and tested, rather than pretending a chat response is the repository. Humanity has invented version control, so we might as well use it.

## Local validation

```bash
python -m compileall -q services tests
python -m pytest -q
```

The Docker services use Python 3.11. `llama-cpp-python` is installed only in the model-serving services.

## Hardware tuning

For a machine with 16 GB RAM and 2 CPU cores, start conservatively:

- `MODEL_THREADS=2`
- `MODEL_BATCH=64` or `128`
- `MODEL_CONTEXT=4096` to `8192`
- `MODEL_GPU_LAYERS=-1` only when a compatible GPU build is actually available

Do not run three large models on a 16 GB/2 CPU machine simultaneously unless the models are appropriately quantized and you have measured memory use. Physics remains annoyingly undefeated.
