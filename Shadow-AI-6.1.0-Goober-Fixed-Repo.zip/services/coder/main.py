import os
from fastapi import FastAPI
from pydantic import BaseModel,Field
from services.common.llm import generate,available,model_name,status as llm_status
app=FastAPI(title='Shadow AI Coding Specialist',version='6.0')
class Assist(BaseModel): request:str=Field(min_length=1,max_length=16000); history:list[dict]=Field(default_factory=list, max_length=40); evidence:str=''
@app.get('/health')
def health(): return {'status':'ok','service':'coder','model':model_name(),'model_available':available(),'llm':llm_status()}
@app.post('/assist')
def assist(x:Assist):
 system='You are Shadow AI\'s coding specialist. Focus on repository engineering, coding, debugging, architecture and tests. Be adversarial about assumptions. Never claim code was tested unless evidence says so.'
 prompt=f"REQUEST:\n{x.request}\n\nHISTORY:\n{x.history[-10:]}\n\nRESEARCH:\n{x.evidence[:12000]}\n\nReturn diagnosis, implementation plan, likely edge cases and exact tests needed."
 return {'response':generate([{'role':'system','content':system},{'role':'user','content':prompt}],int(os.getenv('MAX_TOKENS','1400'))) if available() else 'Coding model unavailable; configure MODEL_PATH/MODEL_URL.','model':os.getenv('MODEL_NAME','Qwen2.5-Coder-14B')}
