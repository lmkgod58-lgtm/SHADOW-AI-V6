import json
import os
import pathlib
import shlex
import subprocess
import time

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="Shadow AI Persistent Repo Workspace", version="6.1")
ROOT = pathlib.Path(os.getenv("WORKSPACE_ROOT", "/data/projects"))
ROOT.mkdir(parents=True, exist_ok=True)


class File(BaseModel):
    path: str = Field(min_length=1, max_length=500)
    content: str = Field(max_length=500_000)


class Patch(BaseModel):
    path: str = Field(min_length=1, max_length=500)
    old: str = Field(min_length=1, max_length=500_000)
    new: str = Field(max_length=500_000)


class Test(BaseModel):
    command: str = Field(default="python -m compileall -q .", max_length=500)
    timeout: int = Field(default=60, ge=1, le=180)


def safe(p: str) -> pathlib.PurePosixPath:
    q = pathlib.PurePosixPath(p)
    if q.is_absolute() or ".." in q.parts or not str(q) or str(q) == ".":
        raise HTTPException(400, "unsafe path")
    return q


def proj(name: str) -> pathlib.Path:
    if not name or "/" in name or "\\" in name or name in {".", ".."}:
        raise HTTPException(400, "invalid project")
    p = ROOT / name
    p.mkdir(parents=True, exist_ok=True)
    (p / ".shadow").mkdir(exist_ok=True)
    return p


def _atomic_write(path: pathlib.Path, content: str) -> None:
    tmp = path.with_name(path.name + ".shadow-tmp")
    try:
        tmp.write_text(content, encoding="utf-8")
        tmp.replace(path)
    finally:
        tmp.unlink(missing_ok=True)


def _snapshot_data(p: pathlib.Path) -> dict:
    files = []
    for f in sorted(p.rglob("*")):
        if f.is_file() and ".shadow" not in f.parts:
            files.append({
                "path": str(f.relative_to(p)),
                "size": f.stat().st_size,
                "mtime": f.stat().st_mtime,
            })
    return {
        "project": p.name,
        "created": time.time(),
        "file_count": len(files),
        "files": files,
    }


@app.get("/health")
def health():
    return {"status": "ok", "service": "workspace", "root": str(ROOT)}


@app.get("/project/tree")
def tree(name: str):
    p = proj(name)
    return {
        "project": name,
        "files": [
            str(f.relative_to(p))
            for f in sorted(p.rglob("*"))
            if f.is_file() and ".shadow" not in f.parts
        ],
    }


@app.get("/project/file")
def read(name: str, path: str):
    p = proj(name) / safe(path)
    if not p.is_file():
        raise HTTPException(404, "file not found")
    try:
        content = p.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        raise HTTPException(415, "file is not UTF-8 text")
    return {"path": path, "content": content, "mtime": p.stat().st_mtime}


@app.post("/project/file")
def write(name: str, x: File):
    p = proj(name) / safe(x.path)
    p.parent.mkdir(parents=True, exist_ok=True)
    _atomic_write(p, x.content)
    return {"ok": True, "path": x.path, "bytes": len(x.content.encode("utf-8"))}


@app.post("/project/patch")
def patch(name: str, x: Patch):
    p = proj(name) / safe(x.path)
    if not p.is_file():
        raise HTTPException(404, "file not found")
    try:
        content = p.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        raise HTTPException(415, "file is not UTF-8 text")
    matches = content.count(x.old)
    if matches != 1:
        raise HTTPException(409, f"expected exactly one match, found {matches}")
    updated = content.replace(x.old, x.new, 1)
    _atomic_write(p, updated)
    return {"ok": True, "path": x.path, "bytes": len(updated.encode("utf-8"))}


def _allowed_command(command: str) -> list[str]:
    try:
        argv = shlex.split(command)
    except ValueError:
        raise HTTPException(400, "invalid test command")
    if not argv or len(argv) > 20:
        raise HTTPException(400, "test command not allowed")

    # No shell is ever invoked. Keep the test surface intentionally boring.
    allowed = {
        ("python", "-m", "compileall"),
        ("python", "-m", "pytest"),
        ("python", "-m", "unittest"),
        ("pytest",),
    }
    prefix = tuple(argv[:3]) if len(argv) >= 3 else tuple(argv)
    if not (prefix in allowed or tuple(argv[:1]) in allowed):
        raise HTTPException(400, "test command not allowed")

    for token in argv:
        if token.startswith("-") and token not in {
            "-q", "-v", "-x", "--tb=short", "--tb=long", "--disable-warnings",
            "--maxfail=1", "--collect-only",
        }:
            raise HTTPException(400, f"test flag not allowed: {token}")
        if ".." in pathlib.PurePosixPath(token).parts:
            raise HTTPException(400, "unsafe test path")
    return argv


@app.post("/project/test")
def test(name: str, x: Test):
    p = proj(name)
    argv = _allowed_command(x.command)
    started = time.time()
    try:
        result = subprocess.run(
            argv,
            cwd=p,
            capture_output=True,
            text=True,
            timeout=x.timeout,
            env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
        )
    except subprocess.TimeoutExpired as exc:
        return {
            "passed": False,
            "timeout": True,
            "duration": time.time() - started,
            "stdout": (exc.stdout or "")[-12_000:],
            "stderr": (exc.stderr or "")[-12_000:],
        }
    return {
        "passed": result.returncode == 0,
        "timeout": False,
        "returncode": result.returncode,
        "duration": time.time() - started,
        "stdout": result.stdout[-12_000:],
        "stderr": result.stderr[-12_000:],
    }


@app.post("/project/snapshot")
def snapshot(name: str):
    p = proj(name)
    data = _snapshot_data(p)
    stamp = time.strftime("%Y%m%d-%H%M%S", time.gmtime())
    out = p / ".shadow" / f"snapshot-{stamp}.json"
    _atomic_write(out, json.dumps(data, indent=2))
    _atomic_write(p / ".shadow" / "snapshot.json", json.dumps(data, indent=2))
    return {"ok": True, "snapshot": str(out), "file_count": data["file_count"]}


@app.post("/project/validate")
def validate(name: str):
    """Fast repo integrity check before a snapshot/export."""
    p = proj(name)
    files = [
        f for f in p.rglob("*")
        if f.is_file() and ".shadow" not in f.parts
    ]
    errors = []
    for f in files:
        try:
            if f.stat().st_size > 2_000_000:
                errors.append(f"{f.relative_to(p)}: file exceeds 2 MB validation limit")
            if f.suffix.lower() in {".py", ".json", ".toml", ".yaml", ".yml"}:
                f.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            errors.append(f"{f.relative_to(p)}: invalid UTF-8 text")
    return {"valid": not errors, "file_count": len(files), "errors": errors}
