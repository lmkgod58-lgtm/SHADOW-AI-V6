import re
from fastapi import FastAPI
from pydantic import BaseModel,Field
app=FastAPI(title='Shadow AI Context Manager',version='6.0')
class C(BaseModel):text:str=Field(min_length=1,max_length=100000);target_chars:int=7000
@app.get('/health')
def health():return {'status':'ok','service':'context'}
@app.post('/compact')
def compact(x:C):
 t=re.sub(r'\s+',' ',x.text).strip();target=max(1800,min(14000,x.target_chars))
 if len(t)<=target:return {'summary':t,'compressed':False}
 a=int(target*.42);b=int(target*.48);m=target-a-b;mid=max(0,len(t)//2-m//2)
 return {'summary':f'EARLY: {t[:a]}\n\nMIDDLE: {t[mid:mid+m]}\n\nLATEST: {t[-b:]}','compressed':True}
