import os
from fastapi import FastAPI
from pydantic import BaseModel,Field
from services.common.llm import generate,available,model_name,status as llm_status
app=FastAPI(title='Shadow AI Deep Reasoner',version='6.0')
class Reason(BaseModel): request:str=Field(min_length=1,max_length=16000); history:list[dict]=Field(default_factory=list, max_length=40); evidence:str=''; candidate:str=''
@app.get('/health')
def health(): return {'status':'ok','service':'reasoner','model':model_name(),'model_available':available(),'llm':llm_status()}
@app.post('/reason')
def reason(x:Reason):
 system='You are Shadow AI\'s independent reasoning judge. Try to falsify the candidate. Check contradictions, assumptions, evidence quality, edge cases and whether tests actually prove the claim. Return PASS, FAIL, or NEEDS-EVIDENCE with corrections.'
 prompt=f"REQUEST:\n{x.request}\n\nEVIDENCE:\n{x.evidence[:12000]}\n\nCANDIDATE:\n{x.candidate[:16000]}\n\nIndependently audit it."
 return {'response':generate([{'role':'system','content':system},{'role':'user','content':prompt}],int(os.getenv('MAX_TOKENS','1400'))) if available() else 'Reasoning model unavailable; configure MODEL_PATH/MODEL_URL.','model':os.getenv('MODEL_NAME','Qwen3-14B')}
