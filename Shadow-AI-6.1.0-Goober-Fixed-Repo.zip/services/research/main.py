import html,re,socket,ipaddress
from concurrent.futures import ThreadPoolExecutor,as_completed
from urllib.parse import quote_plus,urlparse,urljoin
import requests
from bs4 import BeautifulSoup
from fastapi import FastAPI,HTTPException
from pydantic import BaseModel,Field
app=FastAPI(title='Shadow AI Multi-Source Research',version='6.0'); S=requests.Session(); S.headers.update({'User-Agent':'ShadowAI/6.0 Research'})
class R(BaseModel):
    query:str=Field(min_length=1,max_length=3000)
    max_sources:int=Field(default=10,ge=1,le=12)
class F(BaseModel):url:str=Field(min_length=8,max_length=2048)

def duck(q):
 r=S.get('https://html.duckduckgo.com/html/',params={'q':q},timeout=12);r.raise_for_status();s=BeautifulSoup(r.text,'html.parser');o=[]
 for z in s.select('.result')[:7]:
  a=z.select_one('.result__a');n=z.select_one('.result__snippet')
  if a:o.append({'source':'DuckDuckGo','title':html.unescape(a.get_text(' ',strip=True)),'url':a.get('href',''),'text':html.unescape(n.get_text(' ',strip=True) if n else '')})
 return o
def wiki(q):
 r=S.get('https://en.wikipedia.org/w/api.php',params={'action':'query','list':'search','srsearch':q,'format':'json','srlimit':5},timeout=10);r.raise_for_status();return [{'source':'Wikipedia','title':z.get('title',''),'url':'https://en.wikipedia.org/wiki/'+z.get('title','').replace(' ','_'),'text':BeautifulSoup(z.get('snippet',''),'html.parser').get_text(' ',strip=True)} for z in r.json().get('query',{}).get('search',[])]
def github(q):
 r=S.get('https://api.github.com/search/repositories',params={'q':q,'per_page':5},timeout=10);return [{'source':'GitHub','title':z.get('full_name',''),'url':z.get('html_url',''),'text':z.get('description') or ''} for z in (r.json().get('items',[]) if r.ok else [])]
def arxiv(q):
 r=S.get('https://export.arxiv.org/api/query',params={'search_query':f'all:{q}','max_results':5},timeout=12);r.raise_for_status();s=BeautifulSoup(r.text,'xml');return [{'source':'arXiv','title':z.title.get_text(' ',strip=True),'url':z.id.get_text(strip=True),'text':z.summary.get_text(' ',strip=True)[:1800]} for z in s.find_all('entry')]
def _public_host(hostname: str) -> None:
    try:
        addresses = {ipaddress.ip_address(item[4][0]) for item in socket.getaddrinfo(hostname, None)}
    except socket.gaierror:
        raise HTTPException(400, "host resolution failed")
    if not addresses:
        raise HTTPException(400, "host resolution failed")
    for ip in addresses:
        if any((
            ip.is_private, ip.is_loopback, ip.is_link_local, ip.is_reserved,
            ip.is_multicast, ip.is_unspecified,
        )):
            raise HTTPException(400, "private/local target blocked")


def safe_fetch(url):
    current = url
    for _ in range(3):
        p = urlparse(current)
        if p.scheme not in {"http", "https"} or not p.hostname:
            raise HTTPException(400, "invalid URL")
        _public_host(p.hostname)
        r = S.get(
            current,
            timeout=(5, 15),
            allow_redirects=False,
            headers={"Accept": "text/html,application/xhtml+xml"},
        )
        if 300 <= r.status_code < 400 and r.headers.get("location"):
            current = urljoin(current, r.headers["location"])
            continue
        r.raise_for_status()
        content_type = r.headers.get("content-type", "").lower()
        if content_type and not any(x in content_type for x in ("text/html", "text/plain", "xml")):
            raise HTTPException(415, "unsupported content type")
        soup = BeautifulSoup(r.text, "html.parser")
        for tag in soup(["script", "style", "noscript", "svg"]):
            tag.decompose()
        text = re.sub(r"\s+", " ", soup.get_text(" ", strip=True))
        return {
            "source": urlparse(r.url).netloc,
            "title": soup.title.get_text(" ", strip=True) if soup.title else urlparse(r.url).netloc,
            "url": r.url,
            "text": text[:12000],
        }
    raise HTTPException(400, "too many redirects")

@app.get('/health')
def health():return {'status':'ok','service':'research','sources':['DuckDuckGo','Wikipedia','GitHub','arXiv','direct fetch']}
@app.post('/fetch')
def fetch(x:F):return {'result':safe_fetch(x.url)}
@app.post('/research')
def research(x:R):
 out=[]
 with ThreadPoolExecutor(max_workers=4) as p:
  fs=[p.submit(f,x.query) for f in [duck,wiki,github,arxiv]]
  for f in as_completed(fs):
   try:out.extend(f.result())
   except Exception as e:print('[research]',e)
 seen=set();u=[]
 for z in out:
  k=(z.get('url') or z.get('title','')).lower()
  if k in seen:continue
  seen.add(k);u.append(z)
  if len(u) >= x.max_sources: break
 evidence='\n\n'.join(f"[{i}] {z['title']}\nSOURCE: {z['source']}\nURL: {z['url']}\n{z['text'][:2200]}" for i,z in enumerate(u,1))
 return {'query':x.query,'evidence':evidence,'sources':u}
