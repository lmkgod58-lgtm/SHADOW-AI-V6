"""Local-only LLM runtime shared by Shadow AI model services.

No hosted AI client SDK is used here. Models are loaded from a local GGUF path,
or optionally downloaded from MODEL_URL once at startup.
"""
import os
import threading
import urllib.request
from pathlib import Path

_lock = threading.RLock()
_llm = None
_load_error = None


def _env_int(name: str, default: int, minimum: int, maximum: int) -> int:
    try:
        return max(minimum, min(maximum, int(os.getenv(name, str(default)))))
    except (TypeError, ValueError):
        return default


def model_name() -> str:
    return os.getenv("MODEL_NAME", "local-gguf")


def model_path() -> Path:
    return Path(os.getenv("MODEL_PATH", "/data/models/model.gguf"))


def available() -> bool:
    try:
        import llama_cpp  # noqa: F401
        return True
    except Exception:
        return False


def status() -> dict:
    path = model_path()
    with _lock:
        return {
            "llama_cpp_installed": available(),
            "model": model_name(),
            "model_path": str(path),
            "model_exists": path.is_file(),
            "loaded": _llm is not None,
            "load_error": _load_error,
        }


def _download_model(path: Path) -> None:
    url = os.getenv("MODEL_URL", "").strip()
    if not url:
        raise RuntimeError(f"Model file not found at {path}; set MODEL_PATH or MODEL_URL")

    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".part")
    try:
        urllib.request.urlretrieve(url, tmp)
        if not tmp.is_file() or tmp.stat().st_size < 1024 * 1024:
            raise RuntimeError("Downloaded model is missing or suspiciously small")
        tmp.replace(path)
    finally:
        if tmp.exists():
            tmp.unlink(missing_ok=True)


def _load():
    global _llm, _load_error
    with _lock:
        if _llm is not None:
            return _llm
        if not available():
            raise RuntimeError("llama-cpp-python is not installed")
        try:
            from llama_cpp import Llama
            path = model_path()
            if not path.exists():
                _download_model(path)
            _llm = Llama(
                model_path=str(path),
                n_ctx=_env_int("MODEL_CONTEXT", 8192, 1024, 131072),
                n_threads=_env_int("MODEL_THREADS", 2, 1, 64),
                n_batch=_env_int("MODEL_BATCH", 128, 8, 2048),
                n_gpu_layers=_env_int("MODEL_GPU_LAYERS", 0, -1, 999),
                use_mmap=os.getenv("MODEL_MMAP", "1") != "0",
                use_mlock=os.getenv("MODEL_MLOCK", "0") == "1",
                verbose=False,
            )
            _load_error = None
            return _llm
        except Exception as exc:
            _load_error = f"{type(exc).__name__}: {exc}"
            raise


def generate(messages, max_tokens=900) -> str:
    if not messages:
        raise ValueError("messages cannot be empty")
    max_tokens = max(64, min(8192, int(max_tokens)))
    llm = _load()
    with _lock:
        result = llm.create_chat_completion(
            messages=messages,
            max_tokens=max_tokens,
            temperature=float(os.getenv("MODEL_TEMPERATURE", "0.25")),
            top_p=float(os.getenv("MODEL_TOP_P", "0.9")),
            repeat_penalty=float(os.getenv("MODEL_REPEAT_PENALTY", "1.08")),
        )
    choices = result.get("choices") or []
    content = choices[0].get("message", {}).get("content", "") if choices else ""
    return str(content).strip()
