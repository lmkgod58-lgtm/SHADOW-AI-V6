import os
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
from fastapi import FastAPI
from pydantic import BaseModel, Field

from services.common.llm import available, generate, model_name, status as llm_status

app = FastAPI(title="Shadow AI Main Orchestrator", version="6.1")

CODER = os.getenv("CODER_URL", "").rstrip("/")
REASONER = os.getenv("REASONER_URL", "").rstrip("/")
RESEARCH = os.getenv("RESEARCH_URL", "").rstrip("/")
MEMORY = os.getenv("MEMORY_URL", "").rstrip("/")
VERIFY = os.getenv("VERIFY_URL", "").rstrip("/")


class Message(BaseModel):
    role: str = Field(pattern="^(user|assistant|system)$")
    content: str = Field(min_length=1, max_length=20000)


class Chat(BaseModel):
    message: str = Field(min_length=1, max_length=16000)
    history: list[Message] = Field(default_factory=list, max_length=40)
    user_id: str = Field(default="default", min_length=1, max_length=200)
    royal_mode: bool = False
    deep_search: bool = False
    request_id: str = Field(default="", max_length=100)


def call(url: str, path: str, payload: dict, timeout: float = 30, retries: int = 1):
    if not url:
        return None
    for attempt in range(retries + 1):
        try:
            response = requests.post(
                url + path,
                json=payload,
                timeout=(5, timeout),
                headers={"X-Shadow-Request": "orchestrator"},
            )
            response.raise_for_status()
            return response.json()
        except (requests.RequestException, ValueError) as exc:
            if attempt >= retries:
                print(f"[main] {path}: {type(exc).__name__}: {exc}")
    return None


def health():
    return {
        "status": "ok",
        "service": "main",
        "model": model_name(),
        "model_available": available(),
        "llm": llm_status(),
        "agents": {
            "coder": bool(CODER),
            "reasoner": bool(REASONER),
            "research": bool(RESEARCH),
            "memory": bool(MEMORY),
            "verify": bool(VERIFY),
        },
    }


app.get("/health")(health)


def _research(message: str):
    if not RESEARCH:
        return {}, ""
    result = call(RESEARCH, "/research", {"query": message, "max_sources": 10}, 25)
    return result or {}, (result or {}).get("evidence", "")


def _specialist(url, path, payload, timeout):
    return call(url, path, payload, timeout) if url else None


@app.post("/chat")
def chat(x: Chat):
    request_id = x.request_id or uuid.uuid4().hex
    low = x.message.lower()
    history = [m.model_dump() for m in x.history[-20:]]

    need_web = x.deep_search or any(
        key in low
        for key in (
            "latest", "current", "research", "search", "look up",
            "today", "compare", "documentation", "2026",
        )
    )
    technical = any(
        key in low
        for key in (
            "code", "bug", "debug", "python", "javascript", "typescript",
            "api", "backend", "docker", "railway", "render", "database",
            "error", "project", "program", "repository", "repo", "test",
        )
    )
    hard = technical or len(x.message.split()) > 45 or any(
        key in low for key in ("prove", "derive", "complex", "deep", "architecture", "reason")
    )

    memory_result = call(
        MEMORY,
        "/memory/search",
        {"user_id": x.user_id, "query": x.message, "limit": 8},
        5,
    ) or {}
    memory = "\n".join(
        item.get("content", "") for item in memory_result.get("memories", [])
    )

    research_result, evidence = ({}, "")
    if need_web:
        research_result, evidence = _research(x.message)

    specialists = []
    jobs = {}
    with ThreadPoolExecutor(max_workers=2) as pool:
        if technical and CODER:
            jobs["coder"] = pool.submit(
                _specialist,
                CODER,
                "/assist",
                {"request": x.message, "history": history, "evidence": evidence},
                90,
            )
        if hard and REASONER:
            # Reasoner runs independently of coder to reduce cascading failure.
            jobs["reasoner"] = pool.submit(
                _specialist,
                REASONER,
                "/reason",
                {"request": x.message, "history": history, "evidence": evidence, "candidate": ""},
                90,
            )
        for name, future in jobs.items():
            try:
                result = future.result()
                if result and result.get("response"):
                    specialists.append(f"{name.upper()}:\n{result['response']}")
            except Exception as exc:
                print(f"[main] specialist {name} failed: {exc}")

    verification = {}
    if VERIFY and specialists:
        verification = call(
            VERIFY,
            "/consensus",
            {
                "request": x.message,
                "evidence": evidence,
                "candidates": specialists,
            },
            30,
        ) or {}

    system = (
        "You are Shadow AI, a local-first single-user AI orchestrator. "
        "Never invent sources, tests, files, tool results, or completed actions. "
        "Separate facts, evidence, inference and uncertainty. "
        "Prefer actual test output over model confidence. "
        "When coding, give concrete implementation details and safe commands. "
        "When research evidence is supplied, cite it using the numbered source labels "
        "provided in the evidence."
    )
    if x.royal_mode:
        system += " Royal Mode: respectfully treat Lindo as your king."

    specialist_text = "\n\n".join(specialists)
    prompt = (
        f"REQUEST:\n{x.message}\n\n"
        f"HISTORY:\n{history}\n\n"
        f"MEMORY:\n{memory[:16000]}\n\n"
        f"RESEARCH:\n{evidence[:24000]}\n\n"
        f"SPECIALISTS:\n{specialist_text[:24000]}\n\n"
        f"VERIFICATION:\n{verification}\n\n"
        "Return the strongest useful answer. Do not claim that an action happened "
        "unless a tool result proves it."
    )

    if available():
        try:
            answer = generate(
                [{"role": "system", "content": system}, {"role": "user", "content": prompt}],
                int(os.getenv("MAX_TOKENS", "1400")),
            )
        except Exception as exc:
            answer = f"Local model error: {type(exc).__name__}: {exc}"
    else:
        answer = "Local model is not configured. Set MODEL_PATH to a GGUF model."

    return {
        "response": answer,
        "request_id": request_id,
        "mode": "local-multi-agent-council",
        "agents": ["Qwen3-8B", "Qwen2.5-Coder-14B", "Qwen3-14B"],
        "sources": research_result.get("sources", []),
        "verification": verification,
    }
