import os,sqlite3,time,re
from fastapi import FastAPI,Header,HTTPException
from pydantic import BaseModel,Field
app=FastAPI(title='Shadow AI Memory',version='6.0'); DB=os.getenv('SQLITE_PATH','/data/shadow_memory.db'); KEY=os.getenv('MEMORY_API_KEY',''); os.makedirs(os.path.dirname(DB) or '.',exist_ok=True)
with sqlite3.connect(DB) as c:
    c.execute('CREATE TABLE IF NOT EXISTS memory(id INTEGER PRIMARY KEY,user_id TEXT,kind TEXT,content TEXT,importance INTEGER,created REAL)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_memory_user_created ON memory(user_id,created DESC)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_memory_user_importance ON memory(user_id,importance DESC)')
class Save(BaseModel): user_id:str='default';kind:str='fact';content:str=Field(min_length=1,max_length=16000);importance:int=3
class Search(BaseModel): user_id:str='default';query:str=Field(min_length=1,max_length=1000);limit:int=Field(default=8,ge=1,le=20)
def auth(k):
 if KEY and k!=KEY:raise HTTPException(401,'invalid memory key')
@app.get('/health')
def health():return {'status':'ok','service':'memory'}
@app.post('/memory/save')
def save(x:Save,x_memory_key:str|None=Header(default=None)):
 auth(x_memory_key)
 with sqlite3.connect(DB,timeout=10) as c:c.execute('INSERT INTO memory(user_id,kind,content,importance,created) VALUES(?,?,?,?,?)',(x.user_id,x.kind,x.content,max(1,min(5,x.importance)),time.time()))
 return {'ok':True}
@app.post('/memory/search')
def search(x:Search,x_memory_key:str|None=Header(default=None)):
 auth(x_memory_key); words=[w for w in re.findall(r'[A-Za-z0-9_]+',x.query.lower()) if len(w)>2][:10]
 if not words:return {'memories':[]}
 clauses=' OR '.join('lower(content) LIKE ?' for _ in words); params=[x.user_id]+[f'%{w}%' for w in words]+[max(1,min(20,x.limit))]
 with sqlite3.connect(DB,timeout=10) as c:rows=c.execute(f'SELECT kind,content,importance,created FROM memory WHERE user_id=? AND ({clauses}) ORDER BY importance DESC,created DESC LIMIT ?',params).fetchall()
 return {'memories':[{'kind':a,'content':b,'importance':c,'created_at':d} for a,b,c,d in rows]}
