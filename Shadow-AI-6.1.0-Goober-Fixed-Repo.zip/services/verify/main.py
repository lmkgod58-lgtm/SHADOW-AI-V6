import re
from fastapi import FastAPI
from pydantic import BaseModel
app=FastAPI(title='Shadow AI Evidence Verifier',version='6.0')
class C(BaseModel):request:str;evidence:str='';candidates:list[str]=[]
@app.get('/health')
def health():return {'status':'ok','service':'verify'}
@app.post('/consensus')
def consensus(x:C):
 issues=[]
 for i,c in enumerate(x.candidates):
  if re.search(r'\b(definitely|guaranteed|certainly)\b',c,re.I):issues.append(f'candidate {i+1}: absolute certainty needs evidence')
  if 'tested' in c.lower() and not re.search(r'pass|passed|pytest|compile',c,re.I):issues.append(f'candidate {i+1}: testing claim has no visible result')
 return {'status':'NEEDS-EVIDENCE' if issues else 'REVIEWED','issues':issues,'evidence_present':bool(x.evidence.strip()),'candidate_count':len(x.candidates)}
